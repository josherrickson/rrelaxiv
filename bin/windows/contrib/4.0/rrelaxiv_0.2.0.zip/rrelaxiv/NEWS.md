# rrelaxiv 0.2.0

- Several documentation updates

# rrelaxiv 0.1.0

First release!
