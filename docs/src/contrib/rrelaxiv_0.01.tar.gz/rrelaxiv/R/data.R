##' An example of a small network flow input.
"relaxexample"
