library(testthat)
library(rrelaxiv)

test_check("rrelaxiv")
